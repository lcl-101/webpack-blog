var shimmer = require('../../util/shimmer.js');
var logger = require('../../util/logger.js').child('parsers.wrappers.meap');


function appendSegmentName(agent, options) {

    var url;
    var soapAction;

    if (options && options.url) {
        url = options.url;

        if (options.Headers && options.Headers.SOAPAction) {
            soapAction = parserSoapAction(options.Headers.SOAPAction);

            var action = agent.getAction();

            if (action) {
                action.addCorrectSegmentNameFilter(url, returnFunc.bind(null, soapAction));
            }
        }
        
    }
    
    function returnFunc(soapAction) {
        return soapAction
    }
}

function parserSoapAction(soapAction) {
    var func = "";

    soapAction = soapAction.replace(/"/g, "");
    var httpSymbolIndex = soapAction.indexOf("://");
    
    if (httpSymbolIndex >= 0) {
        var isStarted = false;
        for (var i = httpSymbolIndex + 3, soapActionLen = soapAction.length; i < soapActionLen; i++) {
            if (soapAction[i] === "/") {
                isStarted = true;
            }
            if (isStarted) {
                func += soapAction[i];
            }
        }
    } else {
        func = soapAction;
    }
    

    if (func[0] !== "/") {
        func = "/" + func;
    }

    func += "(SOAP)"
    return func;

    
}
module.exports = function initialize(agent, Application) {
    if (!Application || !Application.AJAX) {
        return logger.verbose("Application's AJAX does not exists.");
    }

    /**
     * 模块名称：APPCan的meap模块
     * 使用soap.func参数重新定义事务名称
     */
    shimmer.wrapMethodOnce(Application.AJAX, 'Application.AJAX', 'Runner', function(callback) {
        return function() {
            logger.debug("Setup meap ajax environment.");

            appendSegmentName(agent, arguments[0]);

            return callback.apply(this, arguments);
        }
    });
};