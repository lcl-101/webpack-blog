var logger = require('../../util/logger.js').child('parsers.wrappers.graphql');

module.exports = function initialize(agent, graphql) {
    if (!graphql || !graphql.graphql) {
        return logger.verbose("invalid graphql module.");
    }
    if (graphql.__wrap) {
        return graphql;
    }
    var wrapGraphql = {};
    for (var key in graphql) {
        if (key === 'execute') {
            defineProperty(key);
        } else {
            var descriptor = Object.getOwnPropertyDescriptor(graphql, key);
            Object.defineProperty(wrapGraphql, key, descriptor);
        }
    }
    wrapGraphql.__wrap = true;
    return wrapGraphql;

    function defineProperty(key) {
        var method = graphql[key];
        if (typeof method !== 'function') {
            return;
        }

        Object.defineProperty(wrapGraphql, key, {
            enumerable: true,
            get: function () {
                return wrappedGraphqlMethod;
            }
        });

        function wrappedGraphqlMethod() {
            if (!agent.enabled()) {
                logger.debug('agent disabled!');
                return method.apply(this, arguments);
            }
            var action = agent.getAction();
            if (action) {
                getContext(action, arguments[0]);
            } else {
                logger.debug("wrap graphql's " + key + ' method, but no action context was found!');
            }
            return method.apply(this, arguments);
        }
    }

    function getContext(action, schema) {
        try {
            var operationName = schema.operationName;
            var variableValues = schema.variableValues;
            var operation;
            if (!operationName) {
                operation = schema.document.definitions[0];
            } else {
                var definitions = schema.document.definitions;
                for (var i = 0, length = definitions.length; i < length; i++) {
                    var definition = definitions[i];
                    if (definition.name && definition.name.value === operationName) {
                        operation = definition;
                        break;
                    }
                }
            }
            operation = operation || {};
            operation = operation.operation || 'unknown';

            action.graphqlContext = {
                operationName: operationName || 'anonymous',
                variableValues: variableValues,
                operation: operation
            };
            logger.debug(action.graphqlContext);
        } catch (e) {
            logger.error(e);
        }
    }
};