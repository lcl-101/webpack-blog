'use strict';

var fs = require('fs');
var os = require('os');
var logger = require('../util/logger').child('common.sampler');
var Timer = require('../util/timer');

var cpu_time = 0;
var last_time_stamp = Date.now() - process.uptime() * 1000;
var samplers = [];

function Sampler(sampler, interval) {
    this.hTimer = setInterval(sampler, interval);
    if (this.hTimer.unref) this.hTimer.unref();
}

Sampler.prototype.stop = function stop() {
    clearInterval(this.hTimer);
};

function recordQueueTime(agent, timer) {
    timer.end();
    agent.metrics.measureMilliseconds('Events/Count/Wait', null, timer.getDurationInMillis());
}

function get_value(data, num) {
    var posion = 0;
    for (var index = 0; index < num; index++) {
        posion = data.indexOf(' ', posion);
        if (posion == -1) break;
        posion++;
    }
    if (posion !== -1) return data.slice(posion, data.indexOf(' ', posion));
}

function sampleMemory(agent) {
    return function memorySampler() {
        var mem;
        try {
            mem = process.memoryUsage();
        } catch (e) {
            // may cause by too many open files, uv_resident_set_memory
            // if this happens, also avoid reading cpu info.
            return logger.error(e.message, e);
        }

        readCpu(function (cpu) {
            var enabled = !!agent.config['ns.resource.enabled'];
            if (enabled) {
                var memoryUsed = mem.rss / os.totalmem() * 100;
                var max = memoryUsed;
                var cpuUsed = null;
                if (cpu) {
                    cpuUsed = cpu[1];
                    max = Math.max(max, cpuUsed);
                }
                try {
                    var error;
                    var safe = agent.config['ns.resource.safe'];
                    if (typeof safe !== 'number') {
                        error = new Error('ns.resource.safe needs to be an int value! ');
                        throw error;
                    }
                    logger.debug('current memory & cpu used ratio: ', memoryUsed, cpuUsed);
                    if (max > safe) {
                        logger.debug('Exceed [ns.resource.safe] configuration.', max, safe);
                        // disable all!
                        agent.config.enabled = false;
                        throw new Error('disabled');
                    } else {
                        // reenable agent.
                        agent.config.enabled = true;
                    }
                } catch (e) {
                    logger.error(e.message);
                    if (e.message === 'disabled') {
                        return;
                    }
                }
            } else {
                // in case of modifying tingyun.json on the fly!
                agent.config.enabled = true;
            }

            agent.metrics.measureBytes('Memory/NULL/PhysicalUsed', mem.rss);
            if (cpu) {
                agent.metrics.measureMilliseconds('CPU/NULL/UserTime', null, cpu[0], cpu[0]);
                agent.metrics.measureMilliseconds('CPU/NULL/UserUtilization', null, cpu[1], cpu[1]);
            }
        });

        function readCpu(callback) {
            if (process.platform !== 'linux') {
                return callback(null);
            }
            var file_path = '/proc/' + process.pid + '/stat';
            fs.readFile(file_path, function on_read(err, data) {
                if (err) {
                    logger.error('read cpu error:', file_path, err);
                    return callback(null);
                }
                data = data.toString();
                var cpu_ticks = parseInt(get_value(data, 13)) + parseInt(get_value(data, 14));
                var duration = (cpu_ticks - cpu_time) / 100.0;
                var now = Date.now();
                var cpu_rate = (cpu_ticks - cpu_time) * 10 / (now - last_time_stamp);
                last_time_stamp = now;
                if (cpu_rate > 1) {
                    cpu_rate = 1;
                }
                cpu_rate *= 100;
                cpu_time = cpu_ticks;
                callback([duration, cpu_rate]);
            });
        }
    };
}

function checkEvents(agent) {
    return function eventSampler() {
        var timer = new Timer();
        timer.begin();
        setTimeout(recordQueueTime.bind(null, agent, timer), 0);
    };
}

var sampler = module.exports = {
    state: 'stopped',
    sampleMemory: sampleMemory,
    checkEvents: checkEvents,

    start: function start(agent) {
        samplers.push(new Sampler(sampleMemory(agent), 5000));
        samplers.push(new Sampler(checkEvents(agent), 15000));
        sampler.state = 'running';
    },

    stop: function stop() {
        samplers.forEach(function cb_forEach(sampler) {
            sampler.stop();
        });
        samplers = [];
        sampler.state = 'stopped';
    }
};