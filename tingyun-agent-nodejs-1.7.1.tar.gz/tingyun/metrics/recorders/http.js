'use strict';

var logger = require('../../util/logger').child('metrics.recorders.http');

function recordWeb(segment, scope) {
    // in web metrics, scope is required
    if (!scope) {
        return;
    }
    var duration = segment.getDurationInMillis();
    var exclusive = segment.getExclusiveDurationInMillis();
    var action = segment.trace.action;
    var agent = action.agent;
    var config = agent.config;

    if (config.quantile) {
        logger.debug('action %s duration is: %s', scope, duration);
        agent.quantile.add(scope, duration);
    }

    action.measureAction(scope, null, duration, exclusive);
    if (!segment.partialName) {
        logger.debug('segment partialName is null, use action partialName instead!', action.partialName);
        segment.partialName = action.partialName; // mark segment name as action name, case unknown!
    }
    action.setApdex('Apdex/' + segment.partialName, duration, config.web_actions_apdex[scope]);
}

module.exports = recordWeb;